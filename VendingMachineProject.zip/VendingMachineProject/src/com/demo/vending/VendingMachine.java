package com.demo.vending;

/*
 * Author : Sauveer Pandey
 * This is interface to define public API of vending machine
 */

import java.util.List;

import com.demo.utilities.DrinkAndChange;
import com.demo.utilities.Coin;
import com.demo.utilities.Item;

public interface VendingMachine { 
	public long selectItemAndGetPrice(Item item);
	public void insertCoin(Coin coin); 
	public DrinkAndChange<Item, List<Coin>> buy(); 
	public void reset(); 
}

