package com.demo.utilities;
/*
 * Author : Sauveer Pandey
 * ENUM for drinks available in the vending machine
 */
public enum Item{
    COKE("Coke", 20), PEPSI("Pepsi", 30), SODA("Soda", 40), BEER("Beer", 120);
   
    private String name;
    private int price;
   
    private Item(String name, int price){
        this.name = name;
        this.price = price;
    }
   
    public String getName(){
        return name;
    }
   
    public long getPrice(){
        return price;
    }
}
