package com.demo.utilities;

/*
 * Author : Sauveer Pandey
 * This is a factory class to encapsulate creation logic of vending machine
 */

import com.demo.vending.VendingMachine;
import com.demo.vendingImpl.VendingMachineImpl;

public class VendingMachineFactory { 
	public static VendingMachine createVendingMachine() { 
		return new VendingMachineImpl(); 
	}
}

