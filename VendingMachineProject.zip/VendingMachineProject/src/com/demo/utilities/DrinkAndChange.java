package com.demo.utilities;

/*
 * Author : Sauveer Pandey
 * This is a Holder class for holding two types together. In our case its the drink and the change
 */

public class DrinkAndChange<E1, E2> { 
	private E1 first;
	private E2 second; 
	public DrinkAndChange(E1 first, E2 second){ 
		this.first = first; 
		this.second = second; 
	} 
	public E1 getFirst(){ 
		return first; 
	} 
	public E2 getSecond(){ 
		return second; 
	} 
}

