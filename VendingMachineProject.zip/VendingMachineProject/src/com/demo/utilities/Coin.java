package com.demo.utilities;

/*
 * Author : Sauveer Pandey
 * ENUM for various denominations
 */

public enum Coin { 
	TEN_CENTS(10), TWENTY_CENTS(20), FIFTY_CENTS(50), ONE_EURO(100), TWO_EURO(200);
	private int denomination; 
	private Coin(int denomination){ 
		this.denomination = denomination; 
	} 
	public int getDenomination(){ 
		return denomination; 
	} 
}

