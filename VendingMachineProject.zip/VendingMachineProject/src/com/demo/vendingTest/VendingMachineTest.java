package com.demo.vendingTest;
/*
 * Author : Sauveer Pandey
 * This is a Junit test class to test various scenarios as implemented in vendingMachineImpl
 */

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.Test;

import com.demo.Exceptions.InsufficientChangeException;
import com.demo.Exceptions.SoldOutException;
import com.demo.utilities.DrinkAndChange;
import com.demo.utilities.Coin;
import com.demo.utilities.Item;
import com.demo.utilities.VendingMachineFactory;
import com.demo.vending.VendingMachine;

public class VendingMachineTest { 

	@Test 
	public void testBuyItemWithExactPrice() { 
		VendingMachine vm = VendingMachineFactory.createVendingMachine(); 
		//select item, price in cents 
		long price = vm.selectItemAndGetPrice(Item.COKE); 
		//price should be Coke's price 
		assertEquals(Item.COKE.getPrice(), price); 
		//20 cents paid 
		vm.insertCoin(Coin.TWENTY_CENTS); 
		DrinkAndChange<Item, List<Coin>> bucket = vm.buy(); 
		Item item = bucket.getFirst(); 
		List<Coin> change = bucket.getSecond(); 
		//should be Coke 
		assertEquals(Item.COKE, item); 
		//there should not be any change 
		assertTrue(change.isEmpty()); 
	} 
	
	@Test public void testBuyItemWithMorePriceBeer(){ 
		VendingMachine vm = VendingMachineFactory.createVendingMachine();
		long price = vm.selectItemAndGetPrice(Item.BEER); 
		assertEquals(Item.BEER.getPrice(), price); 
		System.out.println("Price of "+ Item.BEER.getName() + " : "+ Item.BEER.getPrice());
		vm.insertCoin(Coin.TWO_EURO); 
		System.out.println("Customer inserts 2 Euros");
		DrinkAndChange<Item, List<Coin>> bucket = vm.buy(); 
		Item item = bucket.getFirst(); 
		List<Coin> change = bucket.getSecond(); 
		System.out.println("Change returned : ");
		for(Coin c : change){
			System.out.println(c);
		}
		assertEquals(Item.BEER, item); 
		//there should not be any change 
		assertTrue(!change.isEmpty()); 
		//comparing change 
		assertEquals(200 - Item.BEER.getPrice(), getTotal(change)); 
	} 


	@Test public void testBuyItemWithMorePrice(){ 
		VendingMachine vm = VendingMachineFactory.createVendingMachine();
		long price = vm.selectItemAndGetPrice(Item.SODA); 
		assertEquals(Item.SODA.getPrice(), price); 
		vm.insertCoin(Coin.FIFTY_CENTS); 
		vm.insertCoin(Coin.FIFTY_CENTS); 
		DrinkAndChange<Item, List<Coin>> bucket = vm.buy(); 
		Item item = bucket.getFirst(); 
		List<Coin> change = bucket.getSecond(); 
		assertEquals(Item.SODA, item); 
		//there should not be any change 
		assertTrue(!change.isEmpty()); 
		//comparing change 
		assertEquals(100 - Item.SODA.getPrice(), getTotal(change)); 
	} 

	@Test(expected=SoldOutException.class) 
	public void testSoldOut(){ 
		VendingMachine vm = VendingMachineFactory.createVendingMachine();
		for (int i = 0; i < 6; i++) { 
			vm.selectItemAndGetPrice(Item.COKE); 
			vm.insertCoin(Coin.ONE_EURO); 
			vm.buy(); 
		} 
	} 

	@Test(expected=InsufficientChangeException.class) 
	public void testInsufficientChangeException(){ 
		VendingMachine vm = VendingMachineFactory.createVendingMachine(); 
		for (int i = 0; i < 5; i++) { 
			vm.selectItemAndGetPrice(Item.SODA);
			vm.insertCoin(Coin.ONE_EURO); 
			vm.insertCoin(Coin.ONE_EURO); 
			vm.buy(); 
			vm.selectItemAndGetPrice(Item.PEPSI); 
			vm.insertCoin(Coin.ONE_EURO); 
			vm.insertCoin(Coin.ONE_EURO); 
			vm.buy(); 
		} 
	} 

	@Test(expected=SoldOutException.class) 
	public void testReset(){ 
		VendingMachine vmachine = VendingMachineFactory.createVendingMachine(); 
		vmachine.reset(); 
		vmachine.selectItemAndGetPrice(Item.COKE); 
	} 

	private long getTotal(List<Coin> change){ 
		long total = 0; 
		for(Coin c : change){ 
			total = total + c.getDenomination(); 
		} 
		return total; 
	} 
}

