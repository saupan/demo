package com.demo.Exceptions;


/*
 * Author : Sauveer Pandey
 * This is a user defined Exception class that is called when customer inserts amount less than the price of the drink
 */

public class NotFullPaidException extends RuntimeException { 
	private String message; 
	private long remaining; 
	public NotFullPaidException(String message, long remaining) { 
		this.message = message; this.remaining = remaining; 
	} 
	public long getRemaining(){ 
		return remaining; 
	} 
	@Override public String getMessage(){ 
		return message + remaining; 
	} 
}

