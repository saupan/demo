package com.demo.Exceptions;

/*
 * Author : Sauveer Pandey
 * This is a user defined Exception class that is called when customer selects a drink that is not available
 */

public class SoldOutException extends RuntimeException { 
	private String message; 
	public SoldOutException(String string) { 
		this.message = string; 
	} 
	@Override public String getMessage(){ 
		return message; 
	} 
}

