package com.demo.Exceptions;

/*
 * Author : Sauveer Pandey
 * This is a user defined Exception class that is called when the machine doesnt have sufficient change to refund.
 */

public class InsufficientChangeException extends RuntimeException { 
	private String message; 
	
	public InsufficientChangeException(String string) { 
		this.message = string; 
	} 
	@Override public String getMessage(){ 
		return message; 
	} 
}

